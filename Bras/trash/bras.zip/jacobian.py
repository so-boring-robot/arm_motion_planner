import pygame
import math
import numpy as np

# Dimensions de la fenêtre
WIDTH, HEIGHT = 640, 480

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Initialisation de Pygame
pygame.init()
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Simulation de bras mécanique avec pseudo-jacobienne inverse")

clock = pygame.time.Clock()

# Longueurs des segments du bras
BASE_LENGTH = 100
ARM_LENGTH = 100

# Position de la cible
target_pos = None

# Jointure sélectionnée
selected_joint = -1

class RobotArm:
    def __init__(self, num_segments):
        self.num_segments = num_segments
        self.joint_positions = [(WIDTH // 2, HEIGHT),
                   (WIDTH // 2 + ARM_LENGTH, HEIGHT),
                   (WIDTH // 2 + ARM_LENGTH*2, HEIGHT),
                   (WIDTH // 2 + ARM_LENGTH * 3, HEIGHT)]

    # Fonction pour dessiner le bras
    def draw_arm(self):
        pygame.draw.circle(window, RED, self.joint_positions[0], 8)
        for i in range(len(self.joint_positions) - 1):
            pygame.draw.line(window, WHITE, self.joint_positions[i], self.joint_positions[i+1], 5)
            pygame.draw.circle(window, BLUE, self.joint_positions[i+1], 8)

    # Calcul de la pseudo-jacobienne inverse
    def pseudo_inverse_jacobian(self, target_pos):
        max_iterations = 100
        delta_t = 0.01

        link_lengths = [math.hypot(self.joint_positions[i][0] - self.joint_positions[i+1][0],
                                self.joint_positions[i][1] - self.joint_positions[i+1][1])
                        for i in range(len(self.joint_positions) - 1)]

        for _ in range(max_iterations):
            end_effector_pos = self.joint_positions[-1]

            # Calcul de la différence entre la position de l'effecteur et la cible
            delta_pos = np.array([target_pos[0] - end_effector_pos[0], target_pos[1] - end_effector_pos[1]])

            # Calcul de la pseudo-jacobienne inverse
            jacobian = np.zeros((2, self.num_segments))
            for i in range(self.num_segments):
                joint_pos = self.joint_positions[i]
                jacobian[0][i] = (joint_pos[1] - end_effector_pos[1]) / link_lengths[i]
                jacobian[1][i] = (end_effector_pos[0] - joint_pos[0]) / link_lengths[i]

            jacobian_pinv = np.linalg.pinv(jacobian)

            # Calcul de la variation de l'angle des joints
            delta_theta = np.dot(jacobian_pinv, delta_pos)

            # Mise à jour des positions des joints
            for i in range(1, self.num_segments):
                current_joint_pos = np.array(self.joint_positions[i])
                delta_joint_pos = delta_t * delta_theta[i-1]
                new_joint_pos = current_joint_pos + delta_joint_pos
                self.joint_positions[i] = (new_joint_pos[0], new_joint_pos[1])

            # Vérification de la convergence
            distance = math.hypot(self.joint_positions[-1][0] - target_pos[0], self.joint_positions[-1][1] - target_pos[1])
            if distance < 1e-3:
                break


# Fonction pour dessiner la cible
def draw_target(target_pos):
    pygame.draw.circle(window, GREEN, target_pos, 8)

robot_arm = RobotArm(num_segments=3)

def draw_arm(robot_arm):
    pygame.draw.circle(window, RED, robot_arm.joint_positions[0], 8)
    for i in range(len(robot_arm.joint_positions) - 1):
        pygame.draw.line(window, WHITE, robot_arm.joint_positions[i], robot_arm.joint_positions[i+1], 5)
        pygame.draw.circle(window, BLUE, robot_arm.joint_positions[i+1], 8)

# Boucle principale
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Bouton gauche de la souris
                if target_pos is None:
                    target_pos = pygame.mouse.get_pos()
                else:
                    target_pos = pygame.mouse.get_pos()
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Bouton gauche de la souris
                selected_joint = -1

    # Effacer l'écran
    window.fill(BLACK)

    # Mettre à jour la position de la jointure sélectionnée
    if selected_joint != -1:
        prev_x, prev_y = robot_arm.joint_positions[selected_joint]
        robot_arm.joint_positions[selected_joint] = pygame.mouse.get_pos()
        delta_x = robot_arm.joint_positions[selected_joint][0] - prev_x
        delta_y = robot_arm.joint_positions[selected_joint][1] - prev_y
        for i in range(selected_joint + 1, len(robot_arm.joint_positions)):
            robot_arm.joint_positions[i] = (robot_arm.joint_positions[i][0] + delta_x, robot_arm.joint_positions[i][1] + delta_y)

    # Si une cible est présente, appliquer l'algorithme de la pseudo-jacobienne inverse pour atteindre la cible
    if target_pos is not None:
        robot_arm.pseudo_inverse_jacobian(target_pos)

    # Dessiner le bras
    draw_arm(robot_arm)

    # Dessiner la cible
    if target_pos is not None:
        draw_target(target_pos)

    # Rafraîchir l'écran
    pygame.display.flip()
    clock.tick(60)

# Quitter Pygame
pygame.quit()