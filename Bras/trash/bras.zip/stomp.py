import pygame
import numpy as np
import math

# Dimensions de la fenêtre
WIDTH, HEIGHT = 640, 480

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Initialisation de Pygame
pygame.init()
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Simulation de bras mécanique avec STOMP")

clock = pygame.time.Clock()

# Longueurs des segments du bras
BASE_LENGTH = 100
ARM_LENGTH = 100

# Position de la cible
target_pos = None

# Jointure sélectionnée
selected_joint = -1

class RobotArm:
    def __init__(self, num_segments):
        self.num_segments = num_segments
        self.joint_angles = np.zeros(num_segments)
        self.joint_positions = np.zeros((num_segments + 1, 2))
        self.joint_positions[:, 0] = np.cumsum([WIDTH // 2] + [ARM_LENGTH] * num_segments)
        self.joint_positions[:, 1] = HEIGHT

    def update_joint_positions(self):
        # Mise à jour des positions des joints en fonction des angles
        for i in range(1, self.num_segments + 1):
            angle = np.sum(self.joint_angles[:i])
            x = self.joint_positions[i - 1, 0] + ARM_LENGTH * np.cos(angle)
            y = self.joint_positions[i - 1, 1] + ARM_LENGTH * np.sin(angle)
            self.joint_positions[i] = (x, y)

    def draw_arm(self):
        pygame.draw.circle(window, RED, self.joint_positions[0], 8)
        for i in range(self.num_segments):
            pygame.draw.line(window, WHITE, self.joint_positions[i], self.joint_positions[i + 1], 5)
            pygame.draw.circle(window, BLUE, self.joint_positions[i + 1], 8)

    def move_towards_target(self, target_pos, num_iterations, num_samples, learning_rate, noise_scale):
        initial_trajectory = np.copy(self.joint_angles)
        target_trajectory = np.zeros(self.num_segments)

        for i in range(num_iterations):
            current_trajectory = np.copy(self.joint_angles)

            # Génération de trajectoires échantillonnées autour de la trajectoire courante
            sampled_trajectories = []
            for _ in range(num_samples):
                noise = np.random.normal(scale=noise_scale, size=self.num_segments)
                sampled_trajectory = current_trajectory + noise
                sampled_trajectories.append(sampled_trajectory)

            # Calcul de l'évaluation de chaque trajectoire échantillonnée
            costs = []
            for trajectory in sampled_trajectories:
                self.joint_angles = trajectory
                self.update_joint_positions()
                cost = np.linalg.norm(self.joint_positions[-1] - target_pos)
                costs.append(cost)

            # Calcul des poids des trajectoires échantillonnées
            weights = np.exp(-np.array(costs))
            if np.sum(weights) != 0:
                weights /= np.sum(weights)


            # Mise à jour de la trajectoire courante en utilisant les poids et les trajectoires échantillonnées
            update = np.zeros(self.num_segments)
            for j, trajectory in enumerate(sampled_trajectories):
                update += weights[j] * (trajectory - current_trajectory)
            self.joint_angles += learning_rate * update

            self.update_joint_positions()


    def compute_jacobian(self, end_effector_pos):
        jacobian = np.zeros((2, self.num_segments))

        for i in range(self.num_segments):
            segment_vector = self.joint_positions[-1] - self.joint_positions[i]
            jacobian[:, i] = np.array([-segment_vector[1], segment_vector[0]])

        return jacobian

    def set_target(self, target_pos):
        max_iterations = 100
        epsilon = 1e-5

        for _ in range(max_iterations):
            self.update_joint_positions()
            end_effector_pos = self.joint_positions[-1]

            distance = np.linalg.norm(end_effector_pos - target_pos)
            if distance < epsilon:
                break

            jacobian = self.compute_jacobian(end_effector_pos)
            pseudo_inverse = np.linalg.pinv(jacobian)
            delta_angles = np.dot(pseudo_inverse, target_pos - end_effector_pos)

            self.joint_angles += delta_angles

        self.update_joint_positions()

# Création du bras mécanique
robot_arm = RobotArm(num_segments=3)


# Boucle principale
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Bouton gauche de la souris
                target_pos = pygame.mouse.get_pos()
                if math.dist(target_pos, robot_arm.joint_positions[0])<=ARM_LENGTH*robot_arm.num_segments:
                    robot_arm.set_target(target_pos)

    # Effacer l'écran
    window.fill(BLACK)

    # Dessiner le bras mécanique
    robot_arm.draw_arm()

    # Dessiner la cible
    if target_pos is not None:
        pygame.draw.circle(window, GREEN, target_pos, 8)

    # Rafraîchir l'écran
    pygame.display.flip()
    clock.tick(60)

# Quitter Pygame
pygame.quit()