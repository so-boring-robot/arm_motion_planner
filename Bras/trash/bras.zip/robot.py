import pygame
import math

# Dimensions de la fenêtre
WIDTH, HEIGHT = 640, 480

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Initialisation de Pygame
pygame.init()
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Simulation de bras mécanique avec FABRIK")

clock = pygame.time.Clock()

# Longueurs des segments du bras
BASE_LENGTH = 100
ARM_LENGTH = 100

# Positions initiales des jointures du bras
joint_positions = [(WIDTH // 2, HEIGHT // 2),
                   (WIDTH // 2 + BASE_LENGTH, HEIGHT // 2),
                   (WIDTH // 2 + BASE_LENGTH + ARM_LENGTH, HEIGHT // 2),
                   (WIDTH // 2 + BASE_LENGTH + ARM_LENGTH * 2, HEIGHT // 2)]

# Position de la cible
target_pos = None

# Jointure sélectionnée
selected_joint = -1

# Fonction pour dessiner le bras
def draw_arm(joint_positions):
    pygame.draw.circle(window, RED, joint_positions[0], 8)
    for i in range(len(joint_positions) - 1):
        pygame.draw.line(window, WHITE, joint_positions[i], joint_positions[i+1], 5)
        pygame.draw.circle(window, BLUE, joint_positions[i+1], 8)

# Fonction pour dessiner la cible
def draw_target(target_pos):
    pygame.draw.circle(window, GREEN, target_pos, 8)

# Algorithme FABRIK
def fabrik(target_pos, joint_positions):
    epsilon = 1e-5
    max_iterations = 100

    link_lengths = [math.hypot(joint_positions[i][0] - joint_positions[i+1][0],
                               joint_positions[i][1] - joint_positions[i+1][1])
                    for i in range(len(joint_positions) - 1)]

    distance = math.hypot(joint_positions[-1][0] - target_pos[0], joint_positions[-1][1] - target_pos[1])

    if distance <= sum(link_lengths):
        for _ in range(max_iterations):
            # Forward reaching
            joint_positions[-1] = target_pos
            for i in range(len(joint_positions) - 2, -1, -1):
                current_length = math.hypot(joint_positions[i+1][0] - joint_positions[i][0],
                                            joint_positions[i+1][1] - joint_positions[i][1])
                lambda_val = link_lengths[i] / current_length
                joint_positions[i] = ((1 - lambda_val) * joint_positions[i+1][0] + lambda_val * joint_positions[i][0],
                                      (1 - lambda_val) * joint_positions[i+1][1] + lambda_val * joint_positions[i][1])

            # Backward reaching
            joint_positions[0] = (WIDTH // 2, HEIGHT // 2)
            for i in range(len(joint_positions) - 1):
                current_length = math.hypot(joint_positions[i+1][0] - joint_positions[i][0],
                                            joint_positions[i+1][1] - joint_positions[i][1])
                lambda_val = link_lengths[i] / current_length
                joint_positions[i+1] = ((1 - lambda_val) * joint_positions[i][0] + lambda_val * joint_positions[i+1][0],
                                        (1 - lambda_val) * joint_positions[i][1] + lambda_val * joint_positions[i+1][1])

            distance = math.hypot(joint_positions[-1][0] - target_pos[0], joint_positions[-1][1] - target_pos[1])

            if distance < epsilon:
                break

    return joint_positions

# Boucle principale du jeu
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Bouton gauche de la souris
                if target_pos is None:
                    target_pos = pygame.mouse.get_pos()
                else:
                    target_pos = pygame.mouse.get_pos()
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Bouton gauche de la souris
                selected_joint = -1

    # Effacer l'écran
    window.fill(BLACK)

    # Mettre à jour la position de la jointure sélectionnée
    if selected_joint != -1:
        prev_x, prev_y = joint_positions[selected_joint]
        joint_positions[selected_joint] = pygame.mouse.get_pos()
        delta_x = joint_positions[selected_joint][0] - prev_x
        delta_y = joint_positions[selected_joint][1] - prev_y
        for i in range(selected_joint + 1, len(joint_positions)):
            joint_positions[i] = (joint_positions[i][0] + delta_x, joint_positions[i][1] + delta_y)

    # Si une cible est présente, appliquer l'algorithme FABRIK pour atteindre la cible
    if target_pos is not None:
        joint_positions = fabrik(target_pos, joint_positions)

    # Dessiner le bras
    draw_arm(joint_positions)

    # Dessiner la cible
    if target_pos is not None:
        draw_target(target_pos)

    # Rafraîchir l'écran
    pygame.display.flip()
    clock.tick(60)

# Quitter Pygame
pygame.quit()















































import random
import math

""" 
RRT a besoin de plusieurs informations : 
	- La taille de la fenêtre
	- La distance max séparant les nodes
	- la node initiale
	- la node finale
"""

class Node:
	
	def __init__(self, x, y, previous):
		self.x = x
		self.y = y
		self.previous = previous
	
	def getCoordinate(self):
		return (self.x, self.y)

	def toString(self):
		print(f"({x},{y})")

class Screen:
      
      def __init__(self, width, height):
            self.width = width
            self.height = height

class RRT:

    def __init__(self, screen, startPoint, endPoint, obstacles, max_distance):
          self.screen = screen
          self.startPoint = startPoint
          self.endPoint = endPoint
          self.obstacles = obstacles
          self.max_distance = max_distance
          self.nodes = []

    def getPathToTarget(self, path):
        if path[len(path)-1].previous==None:
            return path
        
        path.append(self.nodes[path[len(path)-1].previous])
        self.getPathToTarget(path)

    def nearestNode(self, current_target):
        nearest = 0
        for i in range(len(self.nodes)):
            if math.dist(self.nodes[nearest].getCoordinate(), current_target.getCoordinate()) > math.dist(self.nodes[i].getCoordinate(), current_target.getCoordinate()):
                nearest = i
        return nearest
        
    def nearTarget(self, node):
        return (math.dist(node.getCoordinate(), self.endPoint.getCoordinate()) <= self.max_distance)

    # Savoir si un obstacle se trouve sur la trajectoire revient à savoir 3 points forment une ligne droite
    # https://www.tutorialspoint.com/program-to-check-whether-list-of-points-form-a-straight-line-or-not-in-python
    def isInLine(self, startPoint, endPoint): #start = point le plus proche, end = point à atteindre
        for obstacle in self.obstacles: 
            if (startPoint.x - endPoint.x) * (endPoint.y - obstacle.y) != (endPoint.y - obstacle.x) * (startPoint.y - endPoint.y): 
                return False 
        return True 

    # https://math.stackexchange.com/questions/175896/finding-a-point-along-a-line-a-certain-distance-away-from-another-point/1630886#1630886
    def rapprochePoint(self, startPoint, endPoint, previous):
        ratio = self.max_distance/math.dist(startPoint.getCoordinate(), endPoint.getCoordinate())
        x = ((1-ratio)*startPoint.x+ratio*endPoint.x)
        y = ((1-ratio)*startPoint.y+ratio*endPoint.y)
        return Node(x,y, previous)
    
    def execute(self):
        self.nodes = [self.startPoint]
        path_exist = False
        while not path_exist:

            if not path_exist:
                # Dans un premier temps, il faut générer un x et y random comprit respectivement entre 0 et width/height
                x = random.randint(0, self.screen.width)
                y = random.randint(0, self.screen.height)
                new_node = Node(x,y, None)
                
                # Il faut voir quelle node existante est la plus proche
                nearest = self.nearestNode(new_node)
                
                # Ensuite, il faut trouver un point proportionnel avec une distance convenable
                new_node_near = self.rapprochePoint(self.nodes[nearest], new_node, nearest)
                
                # Il faut maintenant voir si il n'y a pas d'obstacle entre la node la plus proche et la nouvelle node
                inLine = self.isInLine(self.nodes[nearest], new_node_near)
                if(inLine):
                    continue

                self.nodes.append(new_node_near)

                # Pour finir, il faut voir si un chemin existe entre la node courante et la node cible. Pour cela, on peut simplement voir si la dernière node ajouté se trouve aux alentours de la dernière node 			ajoutée, il faudra aussi vérifier qu'il n'y a pas d'obstacles entre ces 2 nodes
                if self.nearTarget(new_node_near):
                    if( not(self.isInLine(new_node_near, self.endPoint)) ):
                        path_exist = True
            
            else :
                pathToTarget = [self.nodes[len(self.nodes)-1]]
                self.getPathToTarget(self.nodes, pathToTarget)
                return pathToTarget 

screen = Screen(800,800)
start = Node(400, 600, None, 0)
end = Node(100,100, None, None)
obstacles = [Node(500,300, None, None)]

path = RRT(screen, start, end, obstacles, 100)
	
	
	
	
	
