class Screen:
      
    def __init__(self, width, height):
        self.width = width
        self.height = height
		
    def getScreen(self):
        return (self.width, self.height)
